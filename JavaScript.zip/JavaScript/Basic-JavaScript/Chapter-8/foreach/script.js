const numbers = [1,2,3,4,5,6];
let text = "";
let sum = 0;
//function


numbers.forEach(sumOfAllArray);

function sumOfAllArray(value,index,array){
    sum += value;
}
document.getElementById("text").innerHTML = sum;

