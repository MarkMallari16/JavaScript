// const numbers = [1,2,3,4,5];

const names = ["mark   ","jobert ","christian   ","irish  "];

let text = document.getElementById("text").innerHTML = names.map((name) => name.toUpperCase());


// function squares(element){
//     return element + 1;

// }
