let num = 20;

// let sum = num + 2;
// let sub = num - 2;
// let pro = num * 2;
// let div = num / 2;
// let mod = num % 2;

//shortcut
num+=2;

function displaySum(p1,p2){
    return p1 + p2;
}
let result = displaySum(20,20);

document.getElementById("test").innerHTML = result;
