let age = window.prompt("How old are you?");

console.log(typeof age);
age = Number(age);

console.log("You are " , age , " years old");