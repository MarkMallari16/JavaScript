window.onload = () => {
    setTimeout(() => {
        // Remove the spinner container
        const spinnerContainer = document.querySelector(".spinner-container");
        if (spinnerContainer) {
            spinnerContainer.remove();
        }
        
        // Display the landing page and add the CSS class to trigger the fade-in animation
        const landingPage = document.querySelector(".landing-page-container");
        if (landingPage) {
            landingPage.classList.remove("d-none");
            landingPage.classList.add("landing-page-fade-in");
        }
    }, 2000); // Adjust the delay as needed
}
