const modal = document.getElementById("modal");
export {modal};